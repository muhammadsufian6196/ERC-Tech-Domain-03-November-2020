<?php

require THIM_DIR . 'inc/admin/thim-core-installer/installer.php';
require THIM_DIR . 'inc/admin/trigger-update-thim-core-1.0.4.php';