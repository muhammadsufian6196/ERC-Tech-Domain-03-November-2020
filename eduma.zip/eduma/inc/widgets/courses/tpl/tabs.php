<?php
echo '<div class="message message-info">' . esc_html__( 'Current version of LearnPress doesn\'t support this layout. Please upgrade to LearnPress 1.x', 'eduma' ) . '</div>';
return;
