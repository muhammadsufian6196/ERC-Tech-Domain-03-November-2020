<?php

function homesweet_child_enqueue_styles() {
	wp_enqueue_style( 'homesweet-child-style', get_stylesheet_uri() );
}

add_action( 'wp_enqueue_scripts', 'homesweet_child_enqueue_styles', 100 );